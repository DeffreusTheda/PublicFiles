#!/bin/bash
# /* ---- 💫 https://github.com/JaKooLit 💫 ---- */  ##

# For Hyprlock
if [[ -z $(ps aux | grep hyprlock | grep -v grep) ]]; then
	hyprlock -q
fi
